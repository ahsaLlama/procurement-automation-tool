package tool.procurement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProcurementtoolApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProcurementtoolApplication.class, args);
	}
}