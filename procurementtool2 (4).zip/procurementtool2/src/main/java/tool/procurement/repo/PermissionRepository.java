package tool.procurement.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import tool.procurement.model.Permission;


@Repository
public interface PermissionRepository extends CrudRepository<Permission, Integer> {

	int countByRoleName(String string);

	Permission findByRoleName(String string);

}
