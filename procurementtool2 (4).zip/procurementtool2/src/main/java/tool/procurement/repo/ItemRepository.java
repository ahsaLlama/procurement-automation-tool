package tool.procurement.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import tool.procurement.model.Item;

@Repository
public interface ItemRepository extends CrudRepository<Item, Integer> {

	List<Item> findByRequestID(Integer requestID);

	Item findByID(Integer itemID);

}
