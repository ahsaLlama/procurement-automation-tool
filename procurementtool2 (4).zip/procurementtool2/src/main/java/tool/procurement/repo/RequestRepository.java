package tool.procurement.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import tool.procurement.model.Request;

@Repository
public interface RequestRepository extends CrudRepository<Request, Integer> {

    String budgetCode = null;
	List<Request> findByEmail(String email);

	Request findByRequestId(Integer requestId);

	/*
	 * returns a list of requests where the budgetcode matches the provided
	 * budgetcode and it hasnt been approved by the budget holder yet.
	 */
	@Query(value = "select * From request where approvedBH != 'approved' AND approvedBH != 'denied' and budget_code=:budgetCode order by date", nativeQuery = true)
	Iterable<Request> needBHApproval(@Param("budgetCode") String budgetCode);
	
	/*
	 * returns a list of requests where the budgetcode matches the provided
	 * budgetcode and it hasnt been approved by the budget holder yet.
	 */
	@Query(value = "select * From request where budget_code=:budgetCode order by date", nativeQuery = true)
	Iterable<Request> allBH(@Param("budgetCode") String budgetCode);


	/*
	 * returns a list of requests where the request hasnt been approved by the
	 * finance officer yet.
	 */
	@Query(value = "select * From request where approvedBH = 'approved' AND approvedFO = 'wait' order by date", nativeQuery = true)
	List<Request> needFOApproval();

	/*
	 * returns a list of requests that have been fully approved and ordered, but not
	 * yet had their arrival confirmed.
	 */
	@Query(value = "select * From request where approvedBH = 'approved' AND approvedFO = 'approved' AND ordered = 1 AND confirm = 0 order by date", nativeQuery = true)
	List<Request> needConfirmation();

	/*
	 * returns alist of requests that have been fully apporved but not yet ordered.
	 */
	@Query(value = "select * From request where approvedBH = 'approved' AND approvedFO = 'approved' AND ordered = 0 AND confirm = 0 order by date", nativeQuery = true)
	List<Request> needOrdered();

	/*
	 * returns a list of requests that have been fully approved, ordered, arrived,
	 * but not yet confirmed if the invoice has been paid.
	 */
	@Query(value = "select * From request where approvedBH = 'approved' AND approvedFO = 'approved' AND confirm = 1 AND paid = 0 order by date", nativeQuery = true)
	List<Request> needPaidConfirmation();

	/*
	 * returns a list of items that have been fully apporved and proccessed.
	 */
	@Query(value = "select * From request where approvedBH = 'approved' AND approvedFO = 'approved' AND ordered = 1 AND confirm = 1 AND paid = 1 order by date", nativeQuery = true)
	List<Request> completedRequests();

}