package tool.procurement.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import tool.procurement.model.User;

@Repository
public interface UserRepository extends CrudRepository<User, String> {

	int countByUsername(String string);
	
	int countByEmail(String string);

	User findByBudgetCode(String budgetCode);

}
