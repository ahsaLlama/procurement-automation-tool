package tool.procurement.security;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import tool.procurement.model.Permission;
import tool.procurement.model.User;
import tool.procurement.repo.PermissionRepository;
import tool.procurement.repo.UserRepository;

@Component
public class FirstUserConfigurer {
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Autowired
	private PermissionRepository permRepo;
	@Autowired
	private UserRepository userRepo;

	@PostConstruct
	public void setup() {
		//Creates permissions
		if(permRepo.countByRoleName("BH") < 1)
			permRepo.save(new Permission("BH"));
		
		if(permRepo.countByRoleName("USER") < 1)
			permRepo.save(new Permission("USER"));
		
		if(permRepo.countByRoleName("FO") < 1)
			permRepo.save(new Permission("FO"));
		
		if(permRepo.countByRoleName("RO") < 1)
			permRepo.save(new Permission("RO"));
		
		//Creates inital users (using student emails due to email class)
		if (userRepo.countByEmail("hrl22xxg@bangor.ac.uk") < 1) {
			User u = new User();
			u.setUsername("harry");
			u.setEmail("hrl22xxg@bangor.ac.uk");
			u.setPassword(passwordEncoder.encode("password"));
			u.setBudgetCode("123-123");
			List<Permission> p = new LinkedList<Permission>();
			p.add(permRepo.findByRoleName("BH"));
			u.setPermissions(p);
			userRepo.save(u);
		}
		
		if (userRepo.countByEmail("jsw22hfh@bangor.ac.uk") < 1) {
			User u = new User();
			u.setUsername("jess");
			u.setEmail("jsw22hfh@bangor.ac.uk");
			u.setPassword(passwordEncoder.encode("password"));
			List<Permission> p = new LinkedList<Permission>();
			p.add(permRepo.findByRoleName("FO"));
			u.setPermissions(p);
			userRepo.save(u);
		}
		
		if (userRepo.countByEmail("shl22zzk@bangor.ac.uk") < 1) {
			User u = new User();
			u.setUsername("ash");
			u.setEmail("shl22zzk@bangor.ac.uk");
			u.setPassword(passwordEncoder.encode("password"));
			List<Permission> p = new LinkedList<Permission>();
			p.add(permRepo.findByRoleName("RO"));
			u.setPermissions(p);
			userRepo.save(u);
		}
		
		if (userRepo.countByEmail("qsb22ttn@bangor.ac.uk") < 1) {
			User u = new User();
			u.setUsername("qusai");
			u.setEmail("qsb22ttn@bangor.ac.uk");
			u.setPassword(passwordEncoder.encode("password"));
			List<Permission> p = new LinkedList<Permission>();
			p.add(permRepo.findByRoleName("USER"));
			u.setPermissions(p);
			userRepo.save(u);
		}
	}
}
