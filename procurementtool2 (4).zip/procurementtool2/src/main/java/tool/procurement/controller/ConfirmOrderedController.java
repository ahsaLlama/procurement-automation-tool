package tool.procurement.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import tool.procurement.model.Request;
import tool.procurement.repo.RequestRepository;

@Controller
public class ConfirmOrderedController {
	
	@Autowired
	private RequestRepository repo;
	
	/*
	 * Returns the page with the attribute of a travserable list of each request
	 * that has been filtered through the method 'needOrdered' in the request
	 * repository.
	 * 
	 * @param model the page model
	 * 
	 * @return the specified page
	 * 
	 */
	@Secured("ROLE_RO")
	@GetMapping("/confirmOrdered")
	public String form(Model m) {
		m.addAttribute("reqOrdered", repo.needOrdered());
		m.addAttribute("reqArrived", repo.needConfirmation());
		return "/confirmOrdered";
	}

	/*
	 * Returns the page with the attribute of a travserable list of each request
	 * that has been filtered through the method 'needOrdered' in the request
	 * repository.
	 * 
	 * @param model the page model
	 * 
	 * @return the specified page
	 * 
	 */
	@Secured("ROLE_RO")
	@RequestMapping(value = "/confirmOrdered", method = RequestMethod.GET, params = "confirmPlaced")
	public String confirmPlaced(@RequestParam(value = "confirmPlaced", required = false) Integer requestId, Model m) {
		Request confirm = repo.findByRequestId(requestId);
		confirm.setOrdered(true);
		confirm.setStatus("Order placed");
		repo.save(confirm);
		return form(m);
	}

	
	/*
	 * Returns the page with the attribute of a travserable list of each request
	 * that has been filtered through the method 'needConfirmation' in the request
	 * repository.
	 * 
	 * @param model the page model
	 * 
	 * @return the specified page
	 * 
	 */
	@Secured("ROLE_RO")
	@RequestMapping(value = "/confirmOrdered", method = RequestMethod.GET, params = "confirmArrived")
	public String confirmArrived(@RequestParam(value = "confirmArrived", required = false) Integer requestId, Model m) {
		Request confirm = repo.findByRequestId(requestId);
		confirm.setConfirm(true);
		confirm.setStatus("Arrival confirmed");
		repo.save(confirm);
		return form(m);
	}
}