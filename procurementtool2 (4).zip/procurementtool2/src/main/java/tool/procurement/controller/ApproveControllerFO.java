package tool.procurement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import tool.procurement.model.EmailSender;
import tool.procurement.model.Request;
import tool.procurement.model.User;
import tool.procurement.repo.ItemRepository;
import tool.procurement.repo.RequestRepository;

@Controller
public class ApproveControllerFO {
	
	
	@Autowired
	private RequestRepository repo;
	@Autowired
	private ItemRepository itemRepo;

	/*
	 * adds relevant requests to the table for the finance officer ot have acess to.
	 */
	@Secured("ROLE_FO")
	@GetMapping("/financeOfficerView")
	public String form(Model m) {
		if (!m.containsAttribute("req")) {
			m.addAttribute("req", repo.needFOApproval());
			m.addAttribute("paidConfirm", repo.needPaidConfirmation());
		}
		return "financeOfficerView";
	}
	

	@GetMapping("/financeOfficerView/approveFO/{id}")
    @Secured("ROLE_FO")
    public String approve(Model m, @PathVariable("id") int id) {
		m.addAttribute("request", repo.findByRequestId(id));
		m.addAttribute("item", itemRepo.findAll());
        return "approveFO";
    }

	/*Page allows for Budget holder to view the request selected in more detail, with the option to approve/deny with a reason at the bottom.
	 * Functionalitly of the radio buttons done by Qusai with emailing notifications done by Harry.
	 * depending on the param 'approve' this request will have its attributes changed to refelct the outcome of this decision.
	 */
	@RequestMapping(value = "financeOfficerView/approveFO/{id}", method = RequestMethod.GET, params = {"submit"})
	public String submit(@RequestParam(value = "submit", required = false) Integer requestId,
			@RequestParam(value = "reason", required = false) String reason,
			@RequestParam(value = "approve") String approval, @AuthenticationPrincipal User user,
			Model m) {

		Request confirm = repo.findByRequestId(requestId);
		if (approval.equals("approve") || approval == "approve") {
			confirm.setApprovedFO("approved");
			confirm.setStatus("Approved by finance officer");
			repo.save(confirm);
			/*Send approval email (done by Harry)
	        String recipientEmail = user.getEmail(); 
	        String subject = "Request Approval";
	        String body = "Dear User,\n\nYour request has been approved by the budget holder.\n\nThank you.";
	        EmailSender.sendEmail(recipientEmail, subject, body);
	        */
	        /*calls the relevant method to create a new (approved) request at the specificed timeframe
	         * done by Ash, Jess, Qusai
	         */
			if (confirm.getReacurring().equals("Yes")) {
				switch(confirm.getReacurringRate()) {
				  case "weekly":
				    weekly(confirm);
				    break;
				  case "monthly":
					  monthly(confirm);
				    break;
				  case "bi-weekly":
					  biweekly(confirm);
				    break;
				  case "yearly":
					  yearly(confirm);
				}

			}
			return "redirect:/financeOfficerView";
		} else{
			// Send denial email (done by Harry)
	        String recipientEmail = user.getEmail(); 
	        String subject = "Request Denial";
	        String body = "Dear User,\n\nYour request has been denied.\n\nThank you.";
	        EmailSender.sendEmail(recipientEmail, subject, body);
	        
			confirm.setReason(reason);
			confirm.setApprovedFO("denied");
			confirm.setStatus("Request Denied");
			repo.save(confirm);
			return "redirect:/financeOfficerView";
		}

	}
	
	@Scheduled(fixedDelay = 604800)
	public void weekly(Request recurReq) {
		Request req = new Request();
		req = recurReq;
		req.setApprovedBH("approved");
		req.setApprovedFO("approved");
		repo.save(req);
		weekly(req);
	}
	
	@Scheduled(fixedDelay = 1209600)
	public void biweekly(Request recurReq) {
		Request req = new Request();
		req = recurReq;
		req.setApprovedBH("approved");
		req.setApprovedFO("approved");
		repo.save(req);
		biweekly(req);
	}
	
	@Scheduled(fixedDelay = 2592000)
	public void monthly(Request recurReq) {
		Request req = new Request();
		req = recurReq;
		req.setApprovedBH("approved");
		req.setApprovedFO("approved");
		repo.save(req);
		monthly(req);
	}
	
	@Scheduled(fixedDelay = 31536000)
	public void yearly(Request recurReq) {
		Request req = new Request();
		req = recurReq;
		req.setApprovedBH("approved");
		req.setApprovedFO("approved");
		repo.save(req);
		yearly(req);
	}
	

	/*
	 * Returns the page with the attribute of a travserable list of each request
	 * that has been filtered through the method 'needConfirmation' in the request
	 * repository.
	 * 
	 * @param model the page model
	 * 
	 * @return the specified page
	 * 
	 */
	@Secured("ROLE_FO")
	@RequestMapping(value = "/financeOfficerView", method = RequestMethod.GET, params = "confirm")
	public String confirm(@RequestParam(value = "confirm", required = false) Integer requestId, Model m) {
		Request confirm = repo.findByRequestId(requestId);
		confirm.setPaid(true);
		confirm.setStatus("Invoice Paid");
		repo.save(confirm);
		return form(m);
	}
	
	
}
