package tool.procurement.controller;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import tool.procurement.model.Item;
import tool.procurement.model.Request;
import tool.procurement.model.User;
import tool.procurement.repo.ItemRepository;
import tool.procurement.repo.RequestRepository;
import tool.procurement.repo.UserRepository;

@Controller
public class RequestController {
	
	@Autowired
	private RequestRepository requestRepo;
	@Autowired
	private UserRepository userRepo;

	@Autowired
	private ItemRepository itemRepo;

	private Double totalCost = 0.00;

	/*
	 * refenced code as I didn't know how to import the current date for an SQL
	 * format https://www.javatpoint.com/java-sql-date
	 */
	long millis = System.currentTimeMillis();
	java.sql.Date date = new java.sql.Date(millis);

	private LinkedList<Item> totalItems = new LinkedList<Item>();
	private LinkedList<Item> items = new LinkedList<Item>();


	/*
	 * This adds a new item, request and list of items to the model ready for the
	 * user to update. 'allowNew' is used to indicate a space for a new item to be
	 * inputed as an easier way of preveting user's from entering new items when
	 * they shouldn't.
	 */
	@Secured({"ROLE_USER", "ROLE_BH", "ROLE_FO", "ROLE_RO"})
	@GetMapping("/request")
	public String form(Model m) {
		if (!m.containsAttribute("req")) {
			m.addAttribute("item", new Item());
			m.addAttribute("allowNew", true);
			m.addAttribute("req", new Request());
			m.addAttribute("items", items);
		}
		return "request";
	}
	
	/*
	 * This will create a new item object ready to be made, along with allowing it
	 * to be inputted in the page.
	 */
	@Secured({ "ROLE_USER", "ROLE_BH", "ROLE_FO", "ROLE_RO" })
	@RequestMapping(value = "/request", method = RequestMethod.POST, params = "addItem")
	public String addItem(Model m, @ModelAttribute("item") Item item, @Validated @ModelAttribute("req") Request req) {
		items = totalItems;
		m.addAttribute("item", new Item());
		m.addAttribute("items", items);
		m.addAttribute("allowNew", true);
		return form(m);
	}

	/*
	 * This will save the current item to the item repository with a dummy requestID
	 * (to be set once the requestID is set and saved). This will also calculate the
	 * cost of all the items in order to provide the users with a 'total cost' area,
	 * instead of inputting it themselevs.
	 */
	@Secured({ "ROLE_USER", "ROLE_BH", "ROLE_FO", "ROLE_RO" })
	@RequestMapping(value = "/request", method = RequestMethod.POST, params = "itemAdded")
	public String itemAdded(@RequestParam(value = "itemAdded", required = false) Integer ID,
			@ModelAttribute("item") Item item, Model m, @Validated @ModelAttribute("req") Request req,
			@Validated @ModelAttribute("items") LinkedList<Item> items) {
		item.setRequestID(123456789);
		item.setFinalCost(item.getCost() * item.getQuantity());

		totalItems.add(item);
		items = totalItems;

		totalCost = 0.00;
		
		for (Item i : totalItems) {
			totalCost = totalCost + i.getFinalCost();
		}
		itemRepo.save(item);
		m.addAttribute("allowNew", false);
		m.addAttribute("totalCost", totalCost);
		m.addAttribute("items", items);
		return form(m);
	}

	/*
	 * This updates the list of items to remoeve the value specificed and finds the
	 * total cost once again to update the page.
	 */
	@Secured({ "ROLE_USER", "ROLE_BH", "ROLE_FO", "ROLE_RO" })
	@RequestMapping(value = "/request", method = RequestMethod.POST, params = "delete")
	public String delete(@RequestParam(value = "delete", required = false) Integer ID, Model m, @Validated @ModelAttribute("req") Request req) {

		for (Item i : totalItems) {
			if (i.getID().equals(ID)) {
				totalItems.remove(i);
			}
		}
		
		itemRepo.deleteById(ID);
		items = totalItems;

		totalCost = calculate();
		m.addAttribute("allowNew", false);
		m.addAttribute("totalCost", totalCost);
		m.addAttribute("items", items);
		return form(m);
	}

	/*
	 * This checks if the request has an incorract budget code (doesn't exist in the
	 * system, or if the user hasnt provided any items in the request. If this is
	 * the case the page will reload with the relevant error. If neither of these
	 * are the case the request will be saved, and update each id to have a matching
	 * 'requestID'. This will also set certain values in the request object to be
	 * the automatic values, such as the date, email, wether the invoice has been
	 * paid.
	 */
	@RequestMapping(value = "/request", method = RequestMethod.POST, params = "Submit")
	public String Submit(Model m, @AuthenticationPrincipal User user, @Validated @ModelAttribute("req") Request req,
			BindingResult b, @ModelAttribute("item") Item item) {
		List<Item> itemList = itemRepo.findByRequestID(123456789);
		if (!b.hasErrors()) {
			if (userRepo.findByBudgetCode(req.getBudgetCode()) == null) {
				m.addAttribute("message",
						"The budget code that you provided doesn't exist in the system. Please enter a valid one.");
				items = totalItems;
				m.addAttribute("items", items);
				totalCost = calculate();
				m.addAttribute("allowNew", false);
				m.addAttribute("totalCost", totalCost);
				return form(m);
				}
				else if (itemList.isEmpty()) {
				m.addAttribute("message",
						"You haven't provided any items in this request.Please provide item(s) in this request.");
				items = totalItems;
				m.addAttribute("items", items);
				totalCost = calculate();
				m.addAttribute("allowNew", false);
				m.addAttribute("totalCost", totalCost);
				return form(m);
			}

			else{
				Double totalCostPlaceholder = 0.00;
				for (Item i : itemList) {
					totalCostPlaceholder = totalCostPlaceholder + (i.getCost() * i.getQuantity());
				}
				req.setTotalCost(totalCostPlaceholder);
				req.setDate(date);
				req.setEmail(user.getEmail());
				req.setStatus("waiting for budgetholder approval");
				req.setConfirm(false);
				req.setPaid(false);
				req.setOrdered(false);
				req.setReason("N/A");
				req.setApprovedBH("wait");
				req.setApprovedFO("wait");
				requestRepo.save(req);

				for (Item i : itemList) {
					i.setRequestID(req.getRequestId());
					itemRepo.save(i);
				}
				totalItems.clear();
				totalCostPlaceholder = 0.00;
			}
		}
		return "redirect:/menu";
	}

	/*
	 * gets the toal cost of items provided
	 */
	public Double calculate() {
		totalCost = 0.00;
		for (Item i : totalItems) {
			totalCost = totalCost + i.getFinalCost();
		}
		return totalCost;
	}
}