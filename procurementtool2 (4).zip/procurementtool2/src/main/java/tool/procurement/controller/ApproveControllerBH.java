package tool.procurement.controller;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import tool.procurement.model.Item;
import tool.procurement.model.Request;
import tool.procurement.model.User;
import tool.procurement.repo.ItemRepository;
import tool.procurement.repo.RequestRepository;
import tool.procurement.model.EmailSender;

@Controller
public class ApproveControllerBH {

	@Autowired
	private RequestRepository repo;
	@Autowired
	private ItemRepository itemRepo;
	
	
	/*If-else statement prevents the budget holder from approving/denying their own requests. Done by Qusai
	 * The request should go to line manager instead to be approved.
	 */
	@Secured("ROLE_BH")
	@GetMapping("/budgetHolderView")
	public String form(@AuthenticationPrincipal User user, Model m) {
		if (!m.containsAttribute("allReq")) {
			List<Request> relevantRequests = new LinkedList<Request>();
			for (Request i : repo.needBHApproval(user.getBudgetCode())) {
				if (i.getEmail().equals(user.getEmail())) {
				}
				else {
					relevantRequests.add(i);
				}
			}
			m.addAttribute("allReq", repo.allBH(user.getBudgetCode()));
			m.addAttribute("req", relevantRequests);
		}
		return "budgetHolderView";
	}
	
	
	@GetMapping("/budgetHolderView/approveBH/{id}")
    @Secured("ROLE_BH")
    public String approve(Model m, @PathVariable("id") int id) {
		m.addAttribute("request", repo.findByRequestId(id));
		m.addAttribute("item", itemRepo.findAll());
        return "approveBH";
    }

	/*Page allows for Budget holder to view the request selected in more detail, with the option to approve/deny with a reason at the bottom.
	 * Functionalitly of the radio buttons done by Qusai with emailing notifications done by Harry.
	 * depending on the param 'approve' this request will have its attributes changed to refelct the outcome of this decision.
	 */
	@RequestMapping(value = "budgetHolderView/approveBH/{id}", method = RequestMethod.GET, params = {"submit"})
	public String submit(@RequestParam(value = "submit", required = false) Integer requestId,
			@RequestParam(value = "reason", required = false) String reason,
			@RequestParam(value = "approve") String approval, @AuthenticationPrincipal User user,
			Model m) {
		
		System.setProperty("mail.pop3s.ssl.protocols", "TLSv1.2");
		Request confirm = repo.findByRequestId(requestId);
		if (approval.equals("approve") || approval == "approve") {
			confirm.setApprovedBH("approved");
			confirm.setStatus("Approved by budget holder");
			
			//Send approval email (done by Harry)
	        String recipientEmail = user.getEmail(); 
	        String subject = "Request Approval";
	        String body = "Dear User,\n\nYour request has been approved by the budget holder.\n\nThank you.";
	        EmailSender.sendEmail(recipientEmail, subject, body);

			repo.save(confirm);
			return "redirect:/budgetHolderView";
		} else {
			confirm.setReason(reason);
			confirm.setApprovedBH("denied");
			confirm.setStatus("Request Denied");
			//Send denial email (done by Harry)
	        String recipientEmail = user.getEmail(); 
	        String subject = "Request Denial";
	        String body = "Dear User,\n\nYour request has been denied.\n\nThank you.";
	        EmailSender.sendEmail(recipientEmail, subject, body);
			repo.save(confirm);
			return "redirect:/budgetHolderView";
		}

	}

}