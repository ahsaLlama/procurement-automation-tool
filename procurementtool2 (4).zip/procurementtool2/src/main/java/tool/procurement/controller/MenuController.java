package tool.procurement.controller;

import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MenuController {

	/*
	 * @secured only allows users with specified permissions to access
	 */
	@GetMapping("/menu")
	@Secured({"ROLE_USER", "ROLE_BH", "ROLE_FO", "ROLE_RO"})
	public String menu() {
		return "menu";
	}

}
