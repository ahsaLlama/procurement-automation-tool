package tool.procurement.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import tool.procurement.model.User;
import tool.procurement.model.Request;
import tool.procurement.repo.ItemRepository;
import tool.procurement.repo.RequestRepository;

@Controller
public class ViewController {
	
	@Autowired
	private RequestRepository requestRepo;

	@Autowired
	private ItemRepository itemRepo;

	/*
	 * This will retrieve the requestid of the request that has just been approved
	 * and set the status to be approved by the budget holder so that it can move on
	 * to the next stage. This will also save the status of the request so it can be
	 * viewwed by the requesting party before saving this to the repository.
	 *
	 * @param user brings in the information of the currently logged in.
	 * 
	 * @param model the page model
	 * 
	 * @return the specified page
	 */
	@Secured({"ROLE_USER", "ROLE_BH", "ROLE_FO", "ROLE_RO"})
	@GetMapping("/view")
	public String viewAll(@AuthenticationPrincipal User user, Model m) {
		String email = user.getEmail();
		m.addAttribute("req", requestRepo.findByEmail(email));
		return "view";
		
	}
	
	@RequestMapping(value = "/view", method = RequestMethod.GET, params = "detail")
    public String view(Model m, @RequestParam(value = "detail", required = false) Integer requestId) {
		m.addAttribute("request", requestRepo.findByRequestId(requestId));
		m.addAttribute("item", itemRepo.findAll());
        return "/viewOne";
    }
	
	@GetMapping("/viewOne")
    public String viewing(Model m, Integer requestId) {
        return "redirect:/view";
    }
}
