package tool.procurement.model;

import javax.mail.*;
import javax.mail.internet.*;
import java.util.Properties;

//Class written by Harry
public class EmailSender {

    public static void sendEmail(String recipientEmail, String subject, String body) {
        // Sender's email details
        String senderEmail = "hrl22xxg@bangor.ac.uk";
        String password = "FUCKINGpASSword2503";
        String host = "smtp.office365.com";
        int port = 587; // Change this according to your SMTP server configuration

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", port);

        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(senderEmail, password);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(senderEmail));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
            message.setSubject(subject);
            message.setText(body);

            Transport.send(message);

            System.out.println("Email sent successfully to " + recipientEmail);
        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }
    }
}