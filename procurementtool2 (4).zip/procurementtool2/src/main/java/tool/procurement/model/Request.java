
package tool.procurement.model;


import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;


@Entity
public class Request {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer requestId;
	@NotNull
	private String name;
	@NotNull
	private String phone;
	@NotNull
	private String room;
	
	private String email;

	private Date date;


	private Double totalCost;
	@NotNull
	private String budgetCode;
	@NotNull
	private String reacurring;
	
	private Boolean confirm;
	
	private Boolean paid;

	private Boolean ordered;

	private String status;
	
	private String approvedBH;

	private String approvedFO;

	private String reacurringRate;

	private String reason;
	
	private String online;
	
	private String supplier;
	
	private String supplierLink;

	public int getRequestId() {
		return requestId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getRoom() {
		return room;
	}
	public void setRoom(String room) {
		this.room = room;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}

	public Double getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(Double totalCost) {
		this.totalCost = totalCost;
	}

	public String getBudgetCode() {
		return budgetCode;
	}

	public void setBudgetCode(String budgetCode) {
		this.budgetCode = budgetCode;
	}
	public String getReacurring() {
		return reacurring;
	}
	public void setReacurring(String reacurring) {
		this.reacurring = reacurring;
	}

	public void setApprovedBH(String approvedBH) {
		this.approvedBH = approvedBH;
	}

	public String getApprovedBH() {
		return approvedBH;
	}

	public void setApprovedFO(String approvedFO) {
		this.approvedFO = approvedFO;
	}

	public String getApprovedFO() {
		return approvedFO;
	}

	public String getReacurringRate() {
		return reacurringRate;
	}
	
	public void setReacurringRate(String status) {
		this.status = status;
	}

	public void setConfirm(Boolean confirm) {
		this.confirm = confirm;
	}
	public Boolean getConfirm() {
		return confirm;
	}
	
	public void setPaid(Boolean paid) {
		this.paid = paid;
	}

	public Boolean getPaid() {
		return paid;
	}

	public void setOrdered(Boolean ordered) {
		this.ordered = ordered;
	}

	public Boolean getOrdered() {
		return ordered;
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getOnline() {
		return online;
	}
	public void setOnline(String online) {
		this.online = online;
	}
	
	public String getSupplier() {
		return supplier;
	}
	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}
	public String getSupplierLink() {
		return supplierLink;
	}
	public void setSupplierLink(String supplierLink) {
		this.supplierLink = supplierLink;
	}
}


