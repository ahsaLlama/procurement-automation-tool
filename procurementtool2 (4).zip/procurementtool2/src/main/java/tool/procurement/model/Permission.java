package tool.procurement.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;

@Entity
public class Permission {
	public Permission() {
	}
	
	public Permission(String roleName) {
		this.roleName = roleName;
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int permissionID;
	
	@NotNull
	private String roleName;

	public int getPermissionID() {
		return permissionID;
	}

	public void setPermissionID(int permissionID) {
		this.permissionID = permissionID;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
}
